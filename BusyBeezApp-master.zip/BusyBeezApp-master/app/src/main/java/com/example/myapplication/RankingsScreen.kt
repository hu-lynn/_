package com.example.myapplication

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.zIndex

val extracurriculars = listOf(
    "Chemistry & Sustainability Club", "Football", "SPEAC", "UIV-LV Debating", "Basketball",
    "Politics Society", "German Office Hours", "Model UN", "Chemistry Geek Club", "Primary Hub",
    "Teaching German to Primary School Children", "Gardening Club"
)

@Composable
fun RankingsScreen() {
    val initialItems = extracurriculars.toMutableList()

    var items by rememberSaveable { mutableStateOf(initialItems) }
    var previousStates by remember { mutableStateOf(listOf<List<String>>()) }

    var draggingItemIndex by remember { mutableStateOf<Int?>(null) }
    var draggedItemOffset by remember { mutableStateOf(0f) }

    val softYellow = Color(0xFFF5E7B2)

    fun undo() {
        if (previousStates.isNotEmpty()) {
            items = previousStates.last().toMutableList()
            previousStates = previousStates.dropLast(1)
        }
    }

    fun saveState() {
        previousStates = previousStates + listOf(items.toList())
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(softYellow)
            .padding(24.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.End
        ) {
            IconButton(onClick = { undo() }) {
                Icon(
                    painter = painterResource(id = R.drawable.backarrow),
                    contentDescription = "Undo",
                    modifier = Modifier.size(30.dp),
                    tint = Color(0xFF42100B)
                )
            }
        }

        Text(
            text = "Rank Your Preferences",
            fontSize = 28.sp,
            color = Color(0xFF42100B),
            fontWeight = FontWeight.Bold,
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 32.dp)
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            items(items) { item ->
                val index = items.indexOf(item)
                val isBeingDragged = draggingItemIndex == index
                val cardColor = if (isBeingDragged) Color(0xFFE0A75E) else softYellow

                RoundedCard(
                    text = item,
                    rank = index + 1,
                    onDelete = {
                        saveState()
                        items = items.toMutableList().apply { removeAt(index) }
                    },
                    isBeingDragged = isBeingDragged,
                    cardColor = cardColor,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                        .pointerInput(Unit) {
                            detectDragGestures(
                                onDragStart = {
                                    saveState()
                                    draggingItemIndex = index
                                    draggedItemOffset = 0f
                                },
                                onDragEnd = {
                                    draggingItemIndex?.let { oldIndex ->
                                        val newIndex = (oldIndex + (draggedItemOffset / 80.dp.value).toInt())
                                            .coerceIn(0, items.size - 1)
                                        if (newIndex != oldIndex) {
                                            items = items.toMutableList().apply {
                                                val itemToMove = removeAt(oldIndex)
                                                add(newIndex, itemToMove)
                                            }
                                        }
                                    }
                                    draggingItemIndex = null
                                    draggedItemOffset = 0f
                                },
                                onDrag = { change, dragAmount ->
                                    change.consume()
                                    draggedItemOffset += dragAmount.y
                                    draggedItemOffset = draggedItemOffset.coerceIn(
                                        -(items.size - 1) * 80.dp.value,
                                        (items.size - 1) * 80.dp.value
                                    )
                                }
                            )
                        }
                        .offset(y = if (isBeingDragged) draggedItemOffset.dp else 0.dp)
                        .zIndex(if (isBeingDragged) 1f else 0f)
                )
            }
        }
    }
}

@Composable
fun RoundedCard(
    text: String,
    rank: Int,
    onDelete: () -> Unit,
    isBeingDragged: Boolean,
    cardColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .border(2.dp, Color(0xFF42100B), RoundedCornerShape(16.dp))
            .padding(2.dp),
        colors = CardDefaults.cardColors(containerColor = cardColor),
        shape = RoundedCornerShape(16.dp),
    ) {
        Row(
            modifier = Modifier.padding(16.dp).fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Image(
                painter = painterResource(id = R.drawable.star),
                contentDescription = null,
                modifier = Modifier.size(40.dp)
            )

            Box(modifier = Modifier.weight(1f)) {
                Text(
                    text = text,
                    fontSize = 18.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = Color(0xFF42100B)
                )
            }

            Text(
                text = "Rank: $rank",
                fontSize = 18.sp,
                color = Color(0xFF42100B)
            )

            IconButton(onClick = onDelete) {
                Image(
                    painter = painterResource(id = R.drawable.bin),
                    contentDescription = "Delete",
                    modifier = Modifier.size(30.dp)
                )
            }
        }
    }
}

