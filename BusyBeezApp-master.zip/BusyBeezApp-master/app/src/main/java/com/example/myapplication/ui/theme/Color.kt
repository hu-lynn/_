package com.example.myapplication.ui.theme

import androidx.compose.ui.graphics.Color

val LightYellow = Color(0xFFF5E7B2)
val Yellow = Color(0xFFF9D689)
val Orange = Color(0xFFE0A75E)
val Red = Color(0xFF973131)
val Black = Color(0xFF000000)

sealed class ThemeColors(
    val primary: Color,
    val text: Color,
    val surface: Color,
    val background: Color,
    val primaryContainer: Color,
    val secondaryContainer: Color,
) {
    data object LightTheme : ThemeColors(
        text = Black,
        primary = Orange,
        surface = Yellow,
        background = LightYellow,
        primaryContainer = Orange, //topappbar colour
        secondaryContainer = Red // box borders
    )
    data object DarkTheme : ThemeColors(
        text = LightYellow,
        primary = Orange,
        surface = Yellow,
        background = Black,
        primaryContainer = Orange,
        secondaryContainer = Red
    )
}
