package com.example.myapplication

import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember

@Composable
fun JournalScreensNavigation() {
    val currentScreen = remember { mutableStateOf("1") } //starts as 1 to call the journal screen first
    val averageRating = remember { mutableStateOf(0f) }
    val currentDescription = remember { mutableStateOf("") }
    val cardsData = remember { mutableStateOf(mutableListOf<Triple<String, Boolean, Float>>()) }

    when (currentScreen.value) {
        "1" -> JournalScreen(
            onNavigateToRating = { description ->
                currentDescription.value = description//gives the description to the other page
                currentScreen.value = "0"//changes it to 0 to call the other page
            },
            cardsData = cardsData
        )

        "0" -> RatingScreen(
            onNavigateBack = { description, avgRating ->
                //updates the card if it's already in the list
                val updatedList = cardsData.value.map { card ->
                    if (card.first == description && !card.second) {
                        //updates the card to marked as rated (second = true) and apply the rating
                        card.copy(second = true, third = avgRating)
                    } else {
                        card
                    }
                }

                //sets the updated list into cardsData
                cardsData.value = updatedList.toMutableList()

                //switches to the Journal screen
                currentScreen.value = "1"
            },
            onAverageRatingCalculated = { avgRating ->
                averageRating.value = avgRating //updates the average rating
            },
            cardDescription = currentDescription.value,
            cardsData = cardsData
        )
    }
}
