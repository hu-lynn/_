package com.example.myapplication

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.myapplication.ui.theme.Kuanodemo
import com.example.myapplication.ui.theme.Poppins


private val LightYellow = Color(0xFFF5E7B2)
private val AmberYellow = Color(0xFFE0A75E)
private val DarkRedBrown = Color(0xFF42100B)

@Composable
fun HomeScreen(navController: NavController) {
    var selectedButton by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .background(LightYellow)
            .fillMaxSize()
            .padding(24.dp)
    ) {
        Image(
            painter = painterResource(id = R.drawable.buzybeezlogo),
            contentDescription = "Buzy Beez Logo",
            modifier = Modifier
                .size(180.dp)
                .align(Alignment.CenterHorizontally)
                .padding(bottom = 32.dp)
        )

        Text(
            text = "Home",
            fontSize = 32.sp,
            color = DarkRedBrown,
            style = TextStyle(
                fontFamily = Kuanodemo,
                fontWeight = FontWeight.Bold
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp)
        )

        Spacer(modifier = Modifier.height(4.dp))

        Spacer(modifier = Modifier.height(40.dp))

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(24.dp),
            modifier = Modifier.fillMaxSize()
        ) {

            NavigationButton(
                label = "Go to Calendar",
                icon = R.drawable.calendar,
                isSelected = selectedButton == "Calendar",
                onClick = {
                    selectedButton = "Calendar"
                    navController.navigate(AppScreens.CalendarScreen.name)
                }
            )

            NavigationButton(
                label = "Go to Rankings",
                icon = R.drawable.ranking,
                isSelected = selectedButton == "Rankings",
                onClick = {
                    selectedButton = "Rankings"
                    navController.navigate(AppScreens.RankingsScreen.name)
                }
            )

            NavigationButton(
                label = "Go to Journal",
                icon = R.drawable.journal,
                isSelected = selectedButton == "Journal",
                onClick = {
                    selectedButton = "Login"
                    navController.navigate(AppScreens.JournalScreens.name)
                }
            )

            NavigationButton(
                label = "Go to Suggestions",
                icon = R.drawable.suggestions,
                isSelected = selectedButton == "Suggestions",
                onClick = {
                    selectedButton = "Suggestions"
                    navController.navigate(AppScreens.SuggestionsScreen.name)
                }
            )

            NavigationButton(
                label = "Login",
                icon = R.drawable.login,
                isSelected = selectedButton == "Login",
                onClick = {
                    selectedButton = "Login"
                    navController.navigate(AppScreens.LoginScreen.name)
                }
            )
        }
    }
}

@Composable
fun NavigationButton(
    label: String,
    icon: Int,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(60.dp)
            .padding(horizontal = 16.dp),
        colors = ButtonDefaults.buttonColors(containerColor = AmberYellow, contentColor = DarkRedBrown),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Image(
                painter = painterResource(id = icon),
                contentDescription = null,
                modifier = Modifier.size(24.dp)
            )
            Text(
                text = label,
                fontSize = 20.sp,
                color = DarkRedBrown,
                style = TextStyle(
                    fontFamily = Poppins,
                    fontWeight = FontWeight.Bold
                )
            )
        }
    }
}
