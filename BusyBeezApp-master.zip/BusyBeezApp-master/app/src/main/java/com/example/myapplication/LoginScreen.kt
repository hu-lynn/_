package com.example.myapplication

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme.colorScheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.myapplication.ui.theme.Kuanodemo
import com.example.myapplication.ui.theme.Poppins

@Composable
fun LoginScreen(
    navController: NavController,
){
    var username by remember{ mutableStateOf("") } //username is currently nothing
    var password by remember{ mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .background(Color(0xFFF5E7B2))
            .fillMaxSize()
    ){
        Spacer(modifier = Modifier.size(60.dp)) //a gap between the title and the top of the screen

        Text(
            text = "Buzy Beez",
            fontWeight = FontWeight.Bold, //make it bold for contrast
//            change font size
            fontSize = 50.sp,
            style = TextStyle(
                fontFamily = Kuanodemo,
//                fontWeight = FontWeight.Normal,
//                fontStyle = FontStyle.Normal,
            ),
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )

        Spacer(modifier = Modifier.size(5.dp)) //another gap between image and title

        Image(
            painter = painterResource(R.drawable.buzybeezlogo),
            contentDescription = null,
            modifier = Modifier
                .aspectRatio(12f/9f)
                .align(Alignment.CenterHorizontally)
        )

        Spacer(modifier = Modifier.size(25.dp)) //another gap

        TextField(
            value = username,
            onValueChange = {username = it }, //when something is inputted, username changes to that
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .clip(RoundedCornerShape(16.dp)) //make it round edges
                .border(1.dp, colorScheme.surface, RoundedCornerShape(16.dp)), //add a border for contrast and clarity
            placeholder = {Text(text = "Username", fontSize = 15.sp, style = TextStyle(fontFamily = Poppins)) },
        )

        Spacer(modifier = Modifier.size(25.dp)) //the things here is the same for Username

        TextField(
            value = password,
            onValueChange = {password = it },
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .clip(RoundedCornerShape(16.dp))
                .border(1.dp, colorScheme.surface, RoundedCornerShape(16.dp)),
            placeholder = {Text("Password", fontSize = 15.sp)},
            visualTransformation = PasswordVisualTransformation(),
        )

        Spacer(modifier = Modifier.size(25.dp))

        if (errorMessage.isNotEmpty()) {
            Text(text = errorMessage,
                color = Color.Red,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }

        Button(
            onClick = {
                if(username == "Lynn" && password == "123"){
                    navController.navigate(AppScreens.HomeScreen.name)
                }
            },
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .height(50.dp)
                .width(120.dp), //size of button
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE0A75E),
                contentColor = Color(0xFF42100B))
        ) {
            Text(
                text = "Log in",
                fontSize = 20.sp
            )
        }


    }
}

