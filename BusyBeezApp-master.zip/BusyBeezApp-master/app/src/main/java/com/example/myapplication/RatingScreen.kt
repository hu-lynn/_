package com.example.myapplication


import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.contentColorFor
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.myapplication.ui.theme.Kuanodemo
import com.example.myapplication.ui.theme.LightYellow
import com.example.myapplication.ui.theme.Orange
import com.example.myapplication.ui.theme.Yellow

//function is called in JournalScreensNavigation
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RatingScreen(
    onNavigateBack: (String, Float) -> Unit,
    onAverageRatingCalculated: (Float) -> Unit,
    cardDescription: String,
    cardsData: MutableState<MutableList<Triple<String, Boolean, Float>>>,
) {
    val questions = listOf("How much did you enjoy this club today?", "How much did you gain from attending this club today", "How time consuming was this club today?", "How much energy did you gain from the club?", "How much do you want to do this club again?")

    //store the ratings for each of the questions
    val finalRating = remember { mutableStateMapOf<String, Int>() }
    val ratingsAverage = if (finalRating.isNotEmpty()) {finalRating.values.sum().toFloat() / finalRating.size }else {0f}

    onAverageRatingCalculated(ratingsAverage)//this allows ratingsAverage to be sent back to the other function on the other page

    Scaffold(
        topBar = {
            RatingTopAppBar(cardDescription=cardDescription, ratingsAverage = ratingsAverage)//displays the description and the ratingsAverage on the topappbar
        },


        content = { paddingValues ->

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .background(LightYellow)
            ) {


                Spacer(modifier = Modifier.height(24.dp))
                Text(
                    text = "Rate each question from 1 to 5:",
                    fontSize = 20.sp,
                    modifier = Modifier
                        .border(2.dp, Orange, RoundedCornerShape(16.dp))
                        .padding(16.dp)
                        )
                Spacer(modifier = Modifier.height(24.dp))

                //calls QuestionButton for each question
                questions.forEach { question ->
                    QuestionButton(question) { rating ->
                        finalRating[question] = rating
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Button(//creates the button to send you back to the other screen
                    onClick = {
                        val updatedCards = cardsData.value.map {card ->
                            if (card.first == cardDescription && !card.second){//checks the first card has not been rated yet and that it equals the discription
                                card.copy(second = true, third = ratingsAverage)//if this is true, the triple is changed so that the second item is true to show that it has been rated and the third is the new average
                            }else{
                                card
                            }
                        }
                        cardsData.value = updatedCards.toMutableList()

                        onNavigateBack(cardDescription, ratingsAverage)},
                    modifier = Modifier
                        .border(2.dp, Orange, RoundedCornerShape(16.dp))
                        .padding(2.dp),
                    colors = ButtonDefaults.buttonColors(LightYellow),
                    shape = RoundedCornerShape(16.dp),
                    elevation = ButtonDefaults.elevatedButtonElevation(8.dp),
                )

                {
                    Text(text = "Back to Journal Screen", //shows the text that this button sends you back to the journal screen 1
                        color = Color.Black,
                        style = MaterialTheme.typography.bodyLarge.copy(fontSize = 18.sp))

                }
            }
        }
    )
}

@Composable
fun QuestionButton(question: String, onRatingSelected: (Int) -> Unit) {
    var showRatingDialog by remember { mutableStateOf(false) }//creates another boolean var for whether or not to show the alertdialog

    Button(onClick = { showRatingDialog = true },
        modifier = Modifier
            .border(2.dp, Color(0xFF42100B), RoundedCornerShape(16.dp))
            .padding(2.dp),
        colors = ButtonDefaults.buttonColors(LightYellow),
        shape = RoundedCornerShape(16.dp),
        elevation = ButtonDefaults.elevatedButtonElevation(8.dp),


    ) {
        Text(question, modifier = Modifier,
            fontSize = 18.sp,
            color =  Orange)
    }
    Spacer(modifier = Modifier.height(16.dp))

    if (showRatingDialog) {//is true
        AlertDialog(
            onDismissRequest = { showRatingDialog = false },
            title = { Text("Rate: $question") },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    horizontalAlignment = Alignment.CenterHorizontally

                ){
                    Row(//create all the things that are going to go in the alert dialog in a row
                        modifier = Modifier
                            .fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        //repeat this 5 times to create the 5 stars
                        for (rating in 1..5) {

                            Button(
                                onClick = {
                                    onRatingSelected(rating)
                                    showRatingDialog = false
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(4.dp)
                                    .height(70.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Orange,
                                    contentColor = Orange
                                ),
                                contentPadding = PaddingValues(0.dp)

                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxSize(),
                                        horizontalArrangement = Arrangement.Center,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {


                                    Image(
                                        painter = painterResource(id = R.drawable.star),
                                        contentDescription = "Star",
                                        modifier = Modifier
                                            .size(30.dp)

                                    )
Spacer(modifier = Modifier.width(4.dp))
                                }
                            }
                        }

                    }
                }
            },
            confirmButton = {},
            dismissButton = {//create a cancel button so that the user can exit
                TextButton(onClick = { showRatingDialog = false }, colors = ButtonDefaults.buttonColors(Yellow)) {
                    Text(text = "Cancel",
                        color = Color.Black)
                }
            }
        )
    }
}

//as a design choice, we chose to remove this bar
@ExperimentalMaterial3Api
@Composable
fun RatingTopAppBar(modifier: Modifier = Modifier, cardDescription: String, ratingsAverage: Float){
    CenterAlignedTopAppBar(//creates a center aligned top app bar
        title = {
            Row(verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Start,
                ){

                Text(text = "$cardDescription: $ratingsAverage",
                    style = TextStyle(
                        fontFamily = Kuanodemo,
                        fontWeight = FontWeight.Bold,
                        fontSize = 32.sp
                    )
                )

                Image(
                    painter = painterResource(R.drawable.buzybeezlogo),
                    contentDescription = null,
                    modifier = Modifier
                        .padding(8.dp)
                        .size(80.dp)


                )

            }
        },
        modifier = modifier,
        colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
            containerColor = LightYellow
        )
    )
}
