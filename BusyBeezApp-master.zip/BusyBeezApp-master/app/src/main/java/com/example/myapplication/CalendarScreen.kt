package com.example.myapplication

import android.annotation.SuppressLint
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme.colorScheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("UnrememberedMutableState")
@Composable
fun CalendarScreen(modifier: Modifier = Modifier) {
    Scaffold { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
        ) {
//            create a list for the days of the week
            val days = listOf("Mon", "Tue", "Wed", "Thu", "Fri")

//            create a list for times during the day
            val times = listOf("Before school", "Break", "Lunch 1", "Lunch 2", "After school")

            val scheduleData = remember { mutableStateListOf<MutableList<String>>() }

//            iterate through the list 'times'
            for (i in times.indices) {
//                for each time slot, add a new MutableStateList of (row in the schedule) to the scheduleData list
                scheduleData.add(mutableStateListOf())
//                iterate through the list 'days'
//                within each time slot, add an empty string as a placeholder - this is where the textfields will be
                for (j in days.indices) {
                    scheduleData[i].add("")
                }
            }

            Row (
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End, // aligns everything in the row to the right of the screen
            ){
//                loop through each item in the list 'days' and display it in a row
                days.forEach { day ->
                    Text(
                        text = day,
                        modifier = Modifier
                            .padding(start = 7.dp, top = 20.dp, end = 50.dp, bottom = 20.dp) // padding to fit for amazon kindle
                    )
                }
            }

            times.forEachIndexed { timeIndex, time ->
                Row(modifier = Modifier // adds a border between each row (separates the times more clearly)
                    .border(1.dp, colorScheme.secondaryContainer)
                    .weight(1f)
                    .wrapContentSize()
                    .padding(12.dp)
                ) {
                    Text(
                        text = time,
                        modifier = Modifier
                            .weight(1.5f) // set the width of the times so that it's the same for each row, and the whole word displays on one line
                            .padding(10.dp)
                    )
                    days.forEachIndexed { dayIndex, _ -> // add a text field for each of the days
                        var showTextField by remember { mutableStateOf(true) }
                        var text by remember { mutableStateOf(scheduleData[timeIndex][dayIndex]) }
                        val focusManager = LocalFocusManager.current

                        if (showTextField) {
                            TextField(
                                value = text,
                                onValueChange = {
                                    text = it
                                    scheduleData[timeIndex][dayIndex] = it // adds text to a 2d grid when typed in
                                },
                                textStyle = TextStyle(
                                    fontSize = 18.sp // change font size
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f)
                                    .padding(6.dp)
                                    .clickable { showTextField = true }
                                    .border(1.dp, colorScheme.secondaryContainer /*change colour of box border*/, RoundedCornerShape(8.dp)), // match formatting with textfields from LoginScreen
                                colors = TextFieldDefaults.textFieldColors(
                                    containerColor = colorScheme.background,  // change the textfield background colour
                                ),
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                                keyboardActions = KeyboardActions(
                                    onDone = {
                                        focusManager.clearFocus()
                                    }
                                )
                                )
                            } else {
                                Text(text = text,
                                    modifier = Modifier
//                                        add padding between the edge of the textfield and the text
                                        .padding(8.dp))
                            }
                        }
                    }
//                }
            }
        }

    }
}
