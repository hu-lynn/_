package com.example.myapplication

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.myapplication.ui.theme.Kuanodemo


enum class AppScreens(var title: String){
    LoginScreen(title = "Login"),
    CalendarScreen(title = "Calendar"),
    RankingsScreen(title = "Ranking"),
    HomeScreen(title = "Home"),
    JournalScreens(title = "Journal"),
    RatingScreen(title = "Rating"),
    SuggestionsScreen(title = "Suggestions")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppBar(
    currentScreen: AppScreens,
    canNavigateBack: Boolean,
    navigateUp: () -> Unit,
    navigateHome: () -> Unit,
    modifier: Modifier = Modifier
) {
    TopAppBar(
        title = { Text(text = currentScreen.title,
                style = TextStyle(fontFamily = Kuanodemo),
            fontSize = 25.sp,
            modifier = Modifier
            ) },
        colors = TopAppBarDefaults.mediumTopAppBarColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        ),
        modifier = modifier,
        navigationIcon = {
            Row {
                if (canNavigateBack && currentScreen != AppScreens.LoginScreen && currentScreen != AppScreens.HomeScreen) {
                    IconButton(onClick = navigateUp) {
                        Icon(
                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "Back Button"
                        )
                    }
                }
            }
        },
        actions = { // make a home button that navigates to the home screen
            if (currentScreen != AppScreens.LoginScreen && currentScreen != AppScreens.HomeScreen) {
                IconButton(onClick = navigateHome) {
                    Icon(
                        painter = painterResource(id = R.drawable.buzybeezlogo), // add our logo as the home button
                        contentDescription = "Buzy Beez logo",
                        tint = Color.Unspecified, // disable tinting so the image doesn't turn all black
                        modifier = Modifier
                            .padding(end = 8.dp)
                    )
                }
            }
        }
    )
}


@Composable
fun App(
    navController: NavHostController = rememberNavController()
){

    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentScreen = AppScreens.valueOf(
        backStackEntry?.destination?.route ?: AppScreens.LoginScreen.name
    )
    Scaffold(
        topBar = {
            AppBar(
                currentScreen = currentScreen,
                canNavigateBack = navController.previousBackStackEntry != null,
                navigateUp = { navController.navigateUp()},
                navigateHome = { navController.navigate(AppScreens.HomeScreen.name) }
            )
        },
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = AppScreens.HomeScreen.name,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(route = AppScreens.LoginScreen.name) {
                LoginScreen(navController
                )
            }
            composable(route = AppScreens.CalendarScreen.name) {
                CalendarScreen()
            }
            composable(route = AppScreens.HomeScreen.name) {
                HomeScreen(navController)
            }
            composable(route = AppScreens.RankingsScreen.name) {
                RankingsScreen()
            }
            composable(route = AppScreens.JournalScreens.name) {
                JournalScreensNavigation()
            }
            composable(route = AppScreens.SuggestionsScreen.name) {
                SuggestionsScreen()
            }
        }
    }
}

