package com.example.myapplication

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
//import androidx.compose.material3.BasicAlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.myapplication.ui.theme.Kuanodemo
import com.example.myapplication.ui.theme.LightYellow
import com.example.myapplication.ui.theme.Orange
import com.example.myapplication.ui.theme.Poppins
import com.example.myapplication.ui.theme.Yellow


@Composable
fun InfoCard(
    description: String,
    rating: String,
    onNavigateToRating: (String) -> Unit,
    modifier: Modifier = Modifier
)
//function to create the cards with the rating and name of the club as parameters asw as navigation
{


    Button(onClick = {onNavigateToRating(description)},//navigates to rating screen setting the title to the description of the card
        modifier = Modifier
            .border(2.dp, Orange, RoundedCornerShape(16.dp))
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .fillMaxWidth()
            .height(48.dp)
            .wrapContentSize(Alignment.Center),
        colors = ButtonDefaults.buttonColors(
            containerColor = LightYellow,
            contentColor = Orange
        )
    ) {
        Row(//formatting the card in a row
            modifier = modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(
                text = description,
                style = MaterialTheme.typography.titleMedium.copy(fontSize = 18.sp, color = Color.Black),
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 8.dp)
            )


            Text(
                text = "Rating: $rating",
                style = MaterialTheme.typography.titleMedium.copy(fontSize = 16.sp, color = Color.Black),

                modifier = Modifier
                    .wrapContentSize(Alignment.Center)
            )
            Image(
                painter = painterResource(id = R.drawable.downimagetrans),
                contentDescription = "Arrow",
                modifier = Modifier
                    .size(40.dp)
                    .rotate(270.0f)

            )



        }
    }
}

@Composable
fun PlusButton(onClick: () -> Unit, modifier: Modifier = Modifier) {//the no longer used plus button
    Button(
        onClick = onClick,
        modifier = modifier
            .padding(top = 20.dp)
            .fillMaxWidth()
            .wrapContentSize(Alignment.Center)
        ,
        colors = ButtonDefaults.buttonColors(
            containerColor = Yellow,
            contentColor = Orange
        )
    ) {
        Text(
            text = "+"
        )
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JournalScreen(
    onNavigateToRating: (String) -> Unit,
    cardsData: MutableState<MutableList<Triple<String, Boolean, Float>>>,
) {

    Scaffold(
        topBar = {
            //JournalTopAppBar()//calls the top app bar at the top of the scaffold (we removed this)
        },
        content = { paddingValues ->//uses the same padding values for continuity
            Column(
                modifier = Modifier
                    .padding(paddingValues)
                    .fillMaxSize()
                    .background(LightYellow)
            ) {
                Spacer(modifier = Modifier.height(12.dp))
                cardsData.value.forEach { (description, isRated, rating) ->//then calls the infocard
                    InfoCard(
                        description = description,
                        rating = "%.1f".format(rating),
                        onNavigateToRating = { onNavigateToRating(description) }
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                }

                var userInput by remember { mutableStateOf("") }
                var userRating by remember { mutableStateOf("") }  // To capture rating input
                var showRatingDialog by remember { mutableStateOf(false) }
                val sharedTextStyle = MaterialTheme.typography.bodyMedium.copy(
                    fontSize = 16.sp,
                    color = Color.Black,
                    letterSpacing = 0.sp,
                    lineHeight = 20.sp
                )

                TextField(//creates a textfield taking user input for hte description
                    value = userInput,
                    onValueChange = { userInput = it },
                    label = { Text("Enter your club...") },
                    modifier = Modifier
                        .border(
                            width = 2.dp,
                            color = Orange,
                            shape = RoundedCornerShape(8.dp)
                        )
                        .fillMaxWidth()
                        .padding(start = 16.dp, end = 16.dp)
                        .height(56.dp),
                    textStyle = MaterialTheme.typography.bodyMedium.copy(
                        fontSize = 20.sp,
                        color = Color.Black,
                        letterSpacing = 0.sp,
                        lineHeight = 20.sp
                    ),

                    colors = TextFieldDefaults.colors(
                        unfocusedContainerColor = LightYellow,
                        unfocusedTextColor = Color.Black,
                        unfocusedLabelColor = Color.Black,
                        focusedContainerColor = LightYellow,
                        focusedTextColor = Color.Black,
                        focusedLabelColor = Color.Black
                    )
                )

                Spacer(
                    modifier = Modifier.height(12.dp)
                )

                Button(
                    onClick = { showRatingDialog = true },//sets var showRatingDialog to true
                    modifier = Modifier
                        .height(56.dp)
                        .border(
                            width = 2.dp,
                            color = Orange,
                            shape = RoundedCornerShape(8.dp)
                        )
                        .fillMaxWidth()
                        .wrapContentSize(Alignment.Center),

                    colors = ButtonDefaults.buttonColors(
                        containerColor = LightYellow,
                        contentColor = Orange
                    )

                )
                {
                    Box(modifier = Modifier.fillMaxWidth()){//creates a box for easier layout
                        Text(text = "And your rating is...",
                            fontSize = 16.sp,
                            color = Color.Black,
                            modifier = Modifier
                                .align(Alignment.CenterStart)
                                .padding(start = 10.dp),
                            style = TextStyle(fontFamily = Poppins)
                        )
                    }
                }
                if (showRatingDialog) {//is true
                    AlertDialog(
                        onDismissRequest = { showRatingDialog = false },
                        title = { Text("Rate Your Club") },
                        text = {
                            Column(
                                modifier = Modifier.verticalScroll(rememberScrollState()),
                                horizontalAlignment = Alignment.CenterHorizontally

                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceEvenly
                                ) {
                                    // Display rating options from 1 to 5
                                    for (rating in 1..5) {

                                        Button(
                                            onClick = {
                                                userRating = rating.toString()
                                                showRatingDialog = false
                                                if (userInput.isNotBlank() && userRating.isNotBlank()) {
                                                    val rating = userRating.toFloatOrNull(
                                                    )
                                                    if (rating != null) {
                                                        // Adds new entry as a pair of description and rating
                                                        cardsData.value =
                                                            cardsData.value.toMutableList()
                                                                .apply {
                                                                    add(
                                                                        Triple(//triple creates data for description, whether or not it is being displayed and the rating
                                                                            userInput,
                                                                            false,
                                                                            rating
                                                                        )
                                                                    )
                                                                }
                                                        userInput = ""
                                                        userRating = ""
                                                    }
                                                }
                                            },


                                            modifier = Modifier
                                                .weight(1f)
                                                .padding(4.dp)
                                                .height(70.dp),
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = Orange,
                                                contentColor = Orange
                                            ),
                                            contentPadding = PaddingValues(0.dp)

                                        ) {
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxSize(),
                                                horizontalArrangement = Arrangement.Center,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {


                                                Image(
                                                    painter = painterResource(id = R.drawable.star),
                                                    contentDescription = "Star",

                                                    modifier = Modifier
                                                        .size(30.dp)
                                                        .padding(start = 2.dp)
                                                )
                                                Spacer(modifier = Modifier.width(4.dp))
                                            }
                                        }
                                    }
                                }
                            }
                        },
                        confirmButton = {//closes the alertdialog by changing showRatingDialog to false
                            Button(
                                onClick = { showRatingDialog = false },
                                colors = ButtonDefaults.buttonColors(containerColor = Yellow)
                            ) {
                                Text(text = "Close", color = Color.Black)
                            }
                        }
                    )
                }
            }
        }
    )
}



@ExperimentalMaterial3Api
@Composable
fun JournalTopAppBar(modifier: Modifier = Modifier) {
    CenterAlignedTopAppBar(//creates a centerAligned top app bar to go at the top of the page
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Start
            ) {

                Text(
                    text = "Journal",
                    style = TextStyle(
                        fontFamily = Kuanodemo,
                        fontWeight = FontWeight.Bold,
                        fontSize = 32.sp
                    ),
                    color = Color.Black
                )

                Image(
                    painter = painterResource(R.drawable.buzybeezlogo),
                    contentDescription = null,
                    modifier = Modifier
                        .padding(8.dp)
                        .size(80.dp)


                )

            }
        },
        modifier = modifier,
        colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
            containerColor = LightYellow
        )
    )

}
