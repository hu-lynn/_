package com.example.myapplication

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.painterResource

val extracurriculars = listOf(
    "Chemistry & Sustainability Club", "Football", "SPEAC", "UIV-LV Debating", "Basketball",
    "Politics Society", "German Office Hours", "Model UN", "Chemistry Geek Club", "Primary Hub",
    "Teaching German to Primary School Children", "Gardening Club"
)

@Composable
fun RankingsScreenUI() {
    var items by remember { mutableStateOf(extracurriculars.toMutableList()) }
    var draggingItemIndex by remember { mutableStateOf<Int?>(null) }
    var draggedItemOffset by remember { mutableStateOf(0f) }

    val cardHeight = 80.dp

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
            .background(Color(0xFFFFF9C4))
    ) {
        Text(
            text = "Rank Your Preferences",
            fontSize = 24.sp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
                .background(Color(0xFFFFD54F))
                .padding(8.dp)
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize()
        ) {
            items(items) { item ->
                val index = items.indexOf(item)
                val isBeingDragged = draggingItemIndex == index
                val isDropTarget = draggingItemIndex != null && draggingItemIndex != index

                HexagonCard(
                    text = item,
                    rank = index + 1,
                    isBeingDragged = isBeingDragged,
                    isDropTarget = isDropTarget,
                    modifier = Modifier
                        .padding(vertical = 8.dp)
                        .fillMaxWidth()
                        .pointerInput(Unit) {
                            detectDragGestures(
                                onDragStart = {
                                    draggingItemIndex = index
                                    draggedItemOffset = 0f
                                },
                                onDragEnd = {
                                    draggingItemIndex?.let { oldIndex ->
                                        val newIndex = (oldIndex + (draggedItemOffset / cardHeight.value).toInt())
                                            .coerceIn(0, items.size - 1)
                                        if (newIndex != oldIndex) {
                                            items = items.toMutableList().apply {
                                                val itemToMove = removeAt(oldIndex)
                                                add(newIndex, itemToMove)
                                            }
                                        }
                                    }
                                    draggingItemIndex = null
                                    draggedItemOffset = 0f
                                },
                                onDrag = { change, dragAmount ->
                                    change.consume()
                                    draggedItemOffset += dragAmount.y

                                    if (draggingItemIndex != null) {
                                        draggedItemOffset = if (draggedItemOffset > 0) {
                                            draggedItemOffset.coerceIn(0f, (items.size - 1) * cardHeight.value)
                                        } else {
                                            draggedItemOffset.coerceIn(-(items.size - 1) * cardHeight.value, 0f)
                                        }
                                    }
                                }
                            )
                        }
                        .offset(y = if (isBeingDragged) draggedItemOffset.dp else 0.dp)
                )
            }
        }
    }
}

@Composable
fun HexagonCard(
    text: String,
    rank: Int,
    isBeingDragged: Boolean,
    isDropTarget: Boolean,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = when {
            isBeingDragged -> Color(0xFFFFD54F)
            isDropTarget -> Color(0xFFE0E0E0)
            else -> Color.White
        }),
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Image(
                painter = painterResource(id = R.drawable.star),
                contentDescription = null,
                modifier = Modifier.size(40.dp)
            )
            Box(modifier = Modifier.weight(1f)) {
                Text(
                    text = text,
                    fontSize = 18.sp,
                    maxLines = 1,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                )
            }
            Text(text = "Rank: $rank", fontSize = 18.sp)
        }
    }
}
